export const Sales = () => {
    return <div>Sales Page</div>;
    };