// src/config/apiConfig.ts

const API_BASE_URL = 'http://localhost:3009';

export default API_BASE_URL;
